tipo = input("Qual tipo de carne? ").upper()
kg = int(input("quantas carnes serão? "))

if (kg <= 5) and (tipo == "FILE DUPLO"):
    preço = 4.90
    total = preço * kg
    cartão = input("Tem o cartão Tabajara? Digite Sim ou Não").upper()
    
    if cartão == "SIM":
        desconto = preço * 0.05
        valor_desconto = total - desconto
        cartao2 = "Cartão Tabajara"
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:{cartao2}\n VALOR DO DESCONTO:{valor_desconto}\n VALOR AO TOTAL: {desconto}") 
    else:
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:Sem cartão tabajara\n VALOR DO DESCONTO: 0\n VALOR AO TOTAL: {total}")

if (kg <= 5) and (tipo == "ALCATRA"):
    preço = 5.90
    total = preço * kg
    cartão = input("Tem o cartão Tabajara? Digite Sim ou Não").upper()
    
    if cartão == "SIM":
        desconto = preço * 0.05
        valor_desconto = total - desconto
        cartao2 = "Cartão Tabajara"
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:{cartao2}\n VALOR DO DESCONTO:{valor_desconto}\n VALOR AO TOTAL: {desconto}")  
    else:
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:Sem cartão tabajara\n VALOR DO DESCONTO: 0\n VALOR AO TOTAL: {total}")

if (kg <= 5) and (tipo == "PICANHA"):
    preço = 6.90
    total = preço * kg
    cartão = input("Tem o cartão Tabajara? Digite Sim ou Não").upper()
    
    if cartão == "SIM":
        desconto = preço * 0.05
        valor_desconto = total - desconto 
        cartao2 = "Cartão Tabajara"
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:{cartao2}\n VALOR DO DESCONTO:{valor_desconto}\n VALOR AO TOTAL: {desconto}") 
    else:
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:Sem cartão tabajara\n VALOR DO DESCONTO: 0\n VALOR AO TOTAL: {total}")

if (kg > 5) and (tipo == "FILE DUPLO"):
    preço = 5.80
    total = preço * kg
    cartão = input("Tem o cartão Tabajara? Digite Sim ou Não").upper()
    
    if cartão == "SIM":
        desconto = preço * 0.05
        valor_desconto = total - desconto 
        cartao2 = "Cartão Tabajara"
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:{cartao2}\n VALOR DO DESCONTO:{valor_desconto}\n VALOR AO TOTAL: {desconto}")  
    else:
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:Sem cartão tabajara\n VALOR DO DESCONTO: 0\n VALOR AO TOTAL: {total}")

if (kg > 5) and (tipo == "ALCATRA"):
    preço = 6.80
    total = preço * kg
    cartão = input("Tem o cartão Tabajara? Digite Sim ou Não").upper()
    
    if cartão == "SIM":
        desconto = preço * 0.05
        valor_desconto = total - desconto
        cartao2 = "Cartão Tabajara"
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:{cartao2}\n VALOR DO DESCONTO:{valor_desconto}\n VALOR AO TOTAL: {desconto}")  
    else:
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:Sem cartão tabajara\n VALOR DO DESCONTO: 0\n VALOR AO TOTAL: {total}")

if (kg > 5) and (tipo == "PICANHA"):
    preço = 7.80
    total = preço * kg
    cartão = input("Tem o cartão Tabajara? Digite Sim ou Não").upper()
    
    if cartão == "SIM":
        desconto = preço * 0.05
        valor_desconto = total - desconto 
        cartao2 = "Cartão Tabajara"
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:{cartao2}\n VALOR DO DESCONTO:{valor_desconto}\n VALOR AO TOTAL: {desconto}") 
    else:
        print(f"TIPO DE CARNE: {tipo}\n QUANTIDADE DE CARNES:{kg}\n PREÇO TOTAL:{total}\n TIPO DE PAGAMENTO:Sem cartão tabajara\n VALOR DO DESCONTO: 0\n VALOR AO TOTAL: {total}")

