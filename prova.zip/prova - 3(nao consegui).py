m2 = int(input("informe aqui a quantidade de m²: "))
preço = 80.00
#Calculo para saber os litros
litros = m2/3# <---3 é o valor fixo de metros quadrados por litros, com isso, divido ele pelo m2 informado e assim saberei exatamente a quantidade de litros


