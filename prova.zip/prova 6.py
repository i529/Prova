colaborador = int(input("informe o salario do colaborador: "))

if (colaborador <= 280):
    calculo = (120/100) * colaborador
    calculo2 = calculo - colaborador
    print(f"O salario antes era de {colaborador}")
    print("Reajuste de 20%")
    print(f"Aumento no salario de {calculo2}")
    print(f"O salario foi aumentado para {calculo}")
    
elif (colaborador > 280) and (colaborador <= 700):
    calculo = (115/100) * colaborador
    calculo2 = calculo - colaborador
    print(f"O salario antes era de {calculo2}")
    print("Reajuste de 15%")
    print(f"Aumento no salario de {calculo2}")
    print(f"O salario foi aumentado para {calculo}")

elif (colaborador > 700) and (colaborador < 1500):
    calculo = (110 / 100) * colaborador
    calculo2 = calculo - colaborador
    print(f"O salario antes era de {calculo2}")
    print("Reajuste de 10%")
    print(f"Aumento no salario de {calculo2}")
    print(f"O salario foi aumentado para {calculo}")

else:
    calculo = (105 / 100) * colaborador
    calculo2 = calculo - colaborador
    print(f"O salario antes era de {calculo2}")
    print("Reajuste de 5%")
    print(f"Aumento no salario de {calculo2}")
    print(f"O salario foi aumentado para {calculo}")
    
    
