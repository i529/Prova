dia = int(input("informe o dia: "))
mes = int(input("informe o mes: "))
ano = int(input("informe o ano: "))

if (dia < 1) or (dia > 31):
    print("Data invalida")

elif (mes < 1) or (mes > 12):
    print("Data invalida")

elif (ano < 1000) or (ano > 3000):
    print("Data invalida")

else:
    print("Data válida")
