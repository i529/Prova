hora_salario = int(input("quanto você ganha por hora?: "))
hora_trabalho = int(input("quantas horas você trabalha no mês"))

salario = hora_salario * hora_trabalho

print(salario)
