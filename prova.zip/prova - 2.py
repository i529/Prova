altura  = float(input("informe aqui sua altura: "))
peso_ideal = (72*altura) - 58

print(peso_ideal)
